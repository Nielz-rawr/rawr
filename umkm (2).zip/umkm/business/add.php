<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'seller') {
  die('Akses ditolak');
}

$user_id = $_SESSION['user_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name        = mysqli_real_escape_string($conn, $_POST['name']);
  $description= mysqli_real_escape_string($conn, $_POST['description']);
  $whatsapp   = mysqli_real_escape_string($conn, $_POST['whatsapp']);
  $category   = $_POST['category']; // makanan, fashion, jasa, elektronik

  /* =========================
     VALIDASI KATEGORI
  ========================= */
  if (!in_array($category, ['makanan','fashion','jasa','elektronik'])) {
    $error = 'Kategori usaha tidak valid';
  } else {

    // UPLOAD GAMBAR
    $imageName = null;
    if (!empty($_FILES['image']['name'])) {
      $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
      $allowed = ['jpg','jpeg','png','webp'];

      if (!in_array(strtolower($ext), $allowed)) {
        $error = 'Format gambar tidak didukung';
      } else {
        $imageName = time().'_'.rand(100,999).'.'.$ext;
        move_uploaded_file(
          $_FILES['image']['tmp_name'],
          "../uploads/business/".$imageName
        );
      }
    }

    if ($error === '') {
      $sql = "INSERT INTO businesses 
              (user_id, name, description, whatsapp, category, image)
              VALUES 
              ($user_id, '$name', '$description', '$whatsapp', '$category', '$imageName')";

      if (mysqli_query($conn, $sql)) {
        header("Location: ../dashboard/seller.php");
        exit;
      } else {
        $error = mysqli_error($conn);
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Buat Usaha</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<header>
  <b>Buat Usaha UMKM</b>
  <nav>
    <a href="../dashboard/seller.php">Kembali</a>
    <a href="../auth/logout.php">Logout</a>
  </nav>
</header>

<div class="container">
  <div class="card">
    <h2>Data Usaha</h2>

    <?php if ($error): ?>
      <div class="error-box"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <label>Nama Usaha</label>
      <input type="text" name="name" required>

      <label>Deskripsi Usaha</label>
      <textarea name="description" rows="4" required></textarea>

      <label>No. WhatsApp</label>
      <input type="text" name="whatsapp" required>

      <label>Kategori Usaha</label>
      <select name="category" required>
        <option value="">-- Pilih Kategori --</option>
        <option value="makanan">Makanan & Minuman</option>
        <option value="fashion">Fashion</option>
        <option value="jasa">Jasa</option>
        <option value="elektronik">Elektronik</option>
      </select>

      <label>Foto Usaha</label>
      <input type="file" name="image" accept="image/*" required>

      <button type="submit">Simpan Usaha</button>
    </form>
  </div>
</div>

<footer>© <?= date('Y') ?> UMKM Marketplace</footer>
</body>
</html>
