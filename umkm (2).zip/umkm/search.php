<?php
include 'config/database.php';
$q = $_GET['q'] ?? '';
$data = mysqli_query($conn, "SELECT * FROM businesses WHERE name LIKE '%$q%'");
?>


<form>
<input name="q" placeholder="Cari usaha / produk">
<button>Cari</button>
</form>


<?php while($b = mysqli_fetch_assoc($data)): ?>
<div>
<h3><?= $b['name'] ?></h3>
<a href="business/detail.php?id=<?= $b['id'] ?>">Lihat Usaha</a>
</div>
<?php endwhile; ?>