<?php
$conn = mysqli_connect("localhost", "root", "", "umkm_db");
if (!$conn) {
die("Koneksi database gagal");
}
?>